#' Monte carlo test - Wiegand et all
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{boolean} TRUE if rejects null hypothesis
#' @export
#'
mc_wiegand <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                       alpha = 0.01) {

  output <- vector(mode = "logical", length = 1)
  ts_wiegand <- vector(mode = "numeric", length = nsim)
  sample_ts <- tpsa::psam(obj_sp1, obj_sp2)

  for(i in seq_along(ts_wiegand)) {
    if(i <= nsim/2) {
      ts_wiegand[i] <- psam(obj_sp1, null_wiegand(obj_sp2))
    } else {
      ts_wiegand[i] <- psam(obj_sp2, null_wiegand(obj_sp1))
    }
  }

  if(alternative == "attraction") {
    output <- (mean(ts_wiegand < sample_ts) < alpha)
  }

  if(alternative == "repulsion") {
    output <- (mean(ts_wiegand > sample_ts) < alpha)
  }

  return(output)
}

#' Comparing different ways to simulate null hypothesis
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{data.frame} with power informations
#' @export
#'
mc_power_wiegan_torus <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                                  alpha = 0.01) {

  unique_bbox <- obj_sp1@bbox
  output <- vector(mode = "logical", length = 2)
  aux_torus <- vector(mode = "logical", length = 1)
  aux_wiegand <- vector(mode = "logical", length = 1)

  aux_torus <- tpsa::psat_mc(obj_sp1 = obj_sp1, obj_sp2 = obj_sp2, n_sim = nsim,
                             alternative = alternative, same_bbox = T, alpha = alpha, ts = "psam")$rejects

  aux_wiegand <- mc_wiegand(obj_sp1 = obj_sp1, obj_sp2 = obj_sp2,
                            nsim = nsim, alternative = alternative,
                            alpha = alpha)

  names(output) <- c("torus", "wiegand")

  output[1] <- aux_torus
  output[2] <- aux_wiegand

  return(output)
}

#' Auxiliar function to calculate the power of the test
#'
#' @param nsim \code{integer}
#' @param iter \code{integer}
#' @param max_hc \code{numeric}
#' @param r_att \code{numeric}
#' @param n_1 \code{integer}
#' @param n_2 \code{integer}
#' @param r \code{numeric}
#' @param alpha \code{numeric}
#' @param bbox \code{matrix}
#' @param alternative \code{character}
#'
#' @return \code{data.frame}
#' @export
#'
power_aux_wiegan_torus <- function(nsim = 100, iter = 100, max_hc = NULL, r_att = NULL,
                                   n_1 = 5, n_2 = 5, r = .25, alpha = 0.01,
                                   bbox = matrix(c(0, 1, 0, 1),
                                                 byrow = T, ncol = 2),
                                   alternative = "attraction") {

  wiegand <- vector(mode = "logical", length = iter)
  torus <- vector(mode = "logical", length = iter)


  if(alternative == "attraction") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     r_att = r_att,
                                     bbox = bbox)

      aux <- try(suppressWarnings(mc_power_wiegan_torus(obj_sp1 = sp_data[[1]],
                                                        obj_sp2 = sp_data[[2]],
                                                        nsim = nsim,
                                                        alternative = alternative,
                                                        alpha = alpha)))

      while("try-error" %in% class(aux)) {
        sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                       relation = alternative,
                                       max_hc = max_hc,
                                       bbox = bbox)

        aux <- try(suppressWarnings(mc_power_wiegan_torus(obj_sp1 = sp_data[[1]],
                                                          obj_sp2 = sp_data[[2]],
                                                          nsim = nsim,
                                                          alternative = alternative,
                                                          alpha = alpha)))
      }

      torus[i] <- aux[1]
      wiegand[i] <- aux[2]
    }

    output <- data.frame(r_att = r_att, wiegand = mean(wiegand),
                         torus = mean(torus))
  }

  if(alternative == "repulsion") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     max_hc = max_hc,
                                     bbox = bbox)

      aux <- try(suppressWarnings(mc_power_wiegan_torus(obj_sp1 = sp_data[[1]],
                                                        obj_sp2 = sp_data[[2]],
                                                        nsim = nsim,
                                                        alternative = alternative,
                                                        alpha = alpha)))

      while("try-error" %in% class(aux)) {
        sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                       relation = alternative,
                                       max_hc = max_hc,
                                       bbox = bbox)

        aux <- try(suppressWarnings(mc_power_wiegan_torus(obj_sp1 = sp_data[[1]],
                                                          obj_sp2 = sp_data[[2]],
                                                          nsim = nsim,
                                                          alternative = alternative,
                                                          alpha = alpha)))
      }

      torus[i] <- aux[1]
      wiegand[i] <- aux[2]
    }
    output <- data.frame(hc_distance = max_hc, wiegand = mean(wiegand),
                         torus = mean(torus))
  }

  return(output)

}

#' @useDynLib tpsautils
#' @importFrom Rcpp sourceCpp
#' @importFrom Rcpp evalCpp
NULL
