#' Spatial Polygons Simulation
#'
#' @param n_1 \code{integer} number of polygons from pattern 1;
#' @param n_2 \code{integer} number of polygons from pattern 2;
#' @param relation \code{character} that represents the relationship
#' between the two patterns. Valid inputs are
#' c("independence", "attraction", "repulsion");
#' @param r \code{numeric} representing the size of the polygons, if \code{r_2} is inputed
#' then \code{r} represents the size of polygons from type 1;
#' @param r_2 \code{numeric} representing the size of the polygons from type 2;
#' @param r_att \code{numeric} only used if relation equal to "attraction".
#' Values between 0 and infinity. Low values indicate high attraction;
#' @param max_hc \code{numeric} only used if relation equal to "repulsion".
#' Values between 0 and infinity High values indicate high repulsion;
#' @param bbox \code{matrix} - represents the boundary box;
#' @param points_chull \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 1 if \code{points_chull_2} is set;
#' @param points_chull_2 \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 2;
#' @param beta_1 \code{numeric} only used if relation equal to "repulsion".
#' Represents the intensity of the pattern 1;
#' @param beta_2 \code{numeric} \code{numeric} only used if relation equal to "repulsion".
#' Represents the intensity of the pattern 2.
#'
#' @importFrom stats runif
#' @importFrom stats ecdf
#' @import sp
#' @import spatstat
#' @return a \code{list} containing two process with the inputed relation.
#' @export
sim_data <- function(n_1 = 10, n_2 = 10, relation = "independence",
                     r = .25, r_2 = r,
                     r_att = NULL, max_hc = NULL,
                     bbox = matrix(rep(c(0, 10), 2), ncol = 2, byrow = T),
                     points_chull = 7,
                     points_chull_2 = points_chull,
                     beta_1 = 1, beta_2 = 1) {

  bbox_vec <- as.vector(c(bbox[1,], bbox[2,]))

  if(!relation %in% c("independence", "repulsion", "attraction")) {
    stop("type must be: independence, repulsion, or attraction.")
  }

  if(relation == "attraction" & is.null(r_att)) {
    stop("If type equal to attraction, then r_att must be informed.")
  }

  if(relation == "repulsion" & is.null(max_hc)) {
    stop("If type equal to attraction, then max_hc must be informed.")
  }

  if(relation %in% c("independence", "attraction")) {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq1 <- list(x = runif(n = n_1, min = bbox[1, 1], max = bbox[1, 2]),
                y = runif(n = n_1, min = bbox[2, 1], max = bbox[2, 2]))

    # rm(ab)

    aux <- vector(mode = 'list', length = n_1)

    for(i in seq_len(n_1)) {
      pts_chull <- unif_circle(n = points_chull, cx = Sq1$x[i],
                               cy = Sq1$y[i], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    rm(aux)
  }

  if(relation == "independence") {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq2 <- list(x = runif(n = n_2, min = bbox[1, 1], max = bbox[1, 2]),
                y = runif(n = n_2, min = bbox[2, 1], max = bbox[2, 2]))

    # rm(ab)

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

  }

  if(relation == "attraction") {
    Sq2 <- list(x = vector(mode = 'numeric', length = n_2),
                y = vector(mode = 'numeric', length = n_2))

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      k <- sample(seq_len(length(sq1)), 1)

      # coords <- spatstat::runifdisc(n = 1, radius = r_att,
      #                               centre = sq1@polygons[[k]]@labpt)

      coords <- unif_circle(n = 1, cx = sq1@polygons[[k]]@labpt[1],
                            cy = sq1@polygons[[k]]@labpt[2], r = r_att)

      x <- coords[, 1]
      y <- coords[, 2]

      if(!spatstat::inside.owin(x, y, bbox_vec)) {
        if(x > max(bbox[1,]) | x < min(bbox[1,])) x <- runif(1, bbox[1, 1], bbox[1, 2])
        if(y > max(bbox[2,]) | y < min(bbox[2,])) y <- runif(1, bbox[2, 1], bbox[2, 2])
      }

      Sq2$x[i] <- x
      Sq2$y[i] <- y

      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- SpatialPolygons(aux)

    rm(Sq2, aux, coords)
  }

  if(relation == "repulsion") {

    if(n_1 == n_2) {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  ptypes = c(.5, .5),
                  w = bbox_vec)
    } else {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  w = bbox_vec)
    }

    Hard <- spatstat::rmh(model = mod, start=list(n.start = c(n_1, n_2)),
                          control = list(nrep = 1e4, nverb = 0, p = 1,
                                         fixall = T), verbose = F)

    # Extracting informations

    Sqs_hard <- data.frame(x = Hard$x, y = Hard$y,
                           type = Hard$marks)

    sq1_hard <- Sqs_hard[Sqs_hard$type == "a", ]
    sq2_hard <- Sqs_hard[Sqs_hard$type == "b", ]

    # Creating spatial objects - hardocre

    aux <- vector(mode = 'list', length = n_1)

    for(i in 1:nrow(sq1_hard)) {
      pts_chull <- unif_circle(n = points_chull, cx = sq1_hard[i, 'x'],
                               cy = sq1_hard[i, 'y'], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    aux <- vector(mode = 'list', length = n_2)

    for(i in 1:nrow(sq2_hard)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = sq2_hard[i, 'x'],
                               cy = sq2_hard[i, 'y'], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))
  }

  sq1 <- rgeos::gIntersection(sq1, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq1))
  sq2 <- rgeos::gIntersection(sq2, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq2))

  attr(sq1, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  attr(sq2, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  out <- list(sq1, sq2)

  rm(list = ls()[ls() != "out"])

  return(out)
}

#' Spatial Polygons Simulation - Marginal Matern Cluster
#'
#' @param n_2 \code{integer} number of polygons from pattern 2;
#' @param relation \code{character} that represents the relationship
#' between the two patterns. Valid inputs are
#' c("independence", "attraction", "repulsion");
#' @param r \code{numeric} representing the size of the polygons, if \code{r_2} is inputed
#' then \code{r} represents the size of polygons from type 1;
#' @param r_2 \code{numeric} representing the size of the polygons from type 2;
#' @param r_att \code{numeric} only used if relation equal to "attraction".
#' Values between 0 and infinity. Low values indicate high attraction;
#' @param max_hc \code{numeric} only used if relation equal to "repulsion".
#' Values between 0 and infinity High values indicate high repulsion;
#' @param bbox \code{matrix} - represents the boundary box;
#' @param points_chull \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 1 if \code{points_chull_2} is set;
#' @param points_chull_2 \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 2;
#' @param kappa \code{numeric} intensity of the parent process;
#' @param scale \code{numeric} \code{numeric} radius parameter of the cluster
#' @param mu \code{numeric} \code{numeric} mean number of points from the child process.
#'
#' @importFrom stats runif
#' @importFrom stats ecdf
#' @import sp
#' @import spatstat
#' @return a \code{list} containing two process with the inputed relation.
#' @export
sim_data_mat <- function(n_2 = 10, relation = "independence",
                         r = .25, r_2 = r,
                         r_att = NULL, max_hc = NULL,
                         bbox = matrix(rep(c(0, 10), 2), ncol = 2, byrow = T),
                         points_chull = 7,
                         points_chull_2 = points_chull,
                         kappa = 8, scale = .08, mu = 6) {

  bbox_vec <- as.vector(c(bbox[1,], bbox[2,]))

  if(!relation %in% c("independence", "repulsion", "attraction")) {
    stop("type must be: independence, repulsion, or attraction.")
  }

  if(relation == "attraction" & is.null(r_att)) {
    stop("If type equal to attraction, then r_att must be informed.")
  }

  if(relation == "repulsion" & is.null(max_hc)) {
    stop("If type equal to attraction, then max_hc must be informed.")
  }

  if(relation %in% c("independence", "attraction")) {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq1 <- spatstat::rMatClust(kappa = kappa, scale = scale,
                               mu = mu, owin = bbox_vec)

    # rm(ab)

    aux <- vector(mode = 'list', length = length(Sq1$x))

    for(i in seq_along(Sq1$x)) {
      pts_chull <- unif_circle(n = points_chull, cx = Sq1$x[i],
                               cy = Sq1$y[i], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    rm(aux)
  }

  if(relation == "independence") {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq2 <- list(x = runif(n = n_2, min = bbox[1, 1], max = bbox[1, 2]),
                y = runif(n = n_2, min = bbox[2, 1], max = bbox[2, 2]))

    # rm(ab)

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

  }

  if(relation == "attraction") {
    Sq2 <- list(x = vector(mode = 'numeric', length = n_2),
                y = vector(mode = 'numeric', length = n_2))

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      k <- sample(seq_len(length(sq1)), 1)

      # coords <- spatstat::runifdisc(n = 1, radius = r_att,
      #                               centre = sq1@polygons[[k]]@labpt)

      coords <- unif_circle(n = 1, cx = sq1@polygons[[k]]@labpt[1],
                            cy = sq1@polygons[[k]]@labpt[2], r = r_att)

      x <- coords[, 1]
      y <- coords[, 2]

      if(!spatstat::inside.owin(x, y, bbox_vec)) {
        if(x > max(bbox[1,]) | x < min(bbox[1,])) x <- runif(1, bbox[1, 1], bbox[1, 2])
        if(y > max(bbox[2,]) | y < min(bbox[2,])) y <- runif(1, bbox[2, 1], bbox[2, 2])
      }

      Sq2$x[i] <- x
      Sq2$y[i] <- y

      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- SpatialPolygons(aux)

    rm(Sq2, aux, coords)
  }

  if(relation == "repulsion") {

    if(n_1 == n_2) {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  ptypes = c(.5, .5),
                  w = bbox_vec)
    } else {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  w = bbox_vec)
    }

    Hard <- spatstat::rmh(model = mod, start=list(n.start = c(n_1, n_2)),
                          control = list(nrep = 1e4, nverb = 0, p = 1,
                                         fixall = T), verbose = F)

    # Extracting informations

    Sqs_hard <- data.frame(x = Hard$x, y = Hard$y,
                           type = Hard$marks)

    sq1_hard <- Sqs_hard[Sqs_hard$type == "a", ]
    sq2_hard <- Sqs_hard[Sqs_hard$type == "b", ]

    # Creating spatial objects - hardocre

    aux <- vector(mode = 'list', length = n_1)

    for(i in 1:nrow(sq1_hard)) {
      pts_chull <- unif_circle(n = points_chull, cx = sq1_hard[i, 'x'],
                               cy = sq1_hard[i, 'y'], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    aux <- vector(mode = 'list', length = n_2)

    for(i in 1:nrow(sq2_hard)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = sq2_hard[i, 'x'],
                               cy = sq2_hard[i, 'y'], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))
  }

  sq1 <- rgeos::gIntersection(sq1, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq1))
  sq2 <- rgeos::gIntersection(sq2, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq2))

  attr(sq1, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  attr(sq2, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  out <- list(sq1, sq2)

  rm(list = ls()[ls() != "out"])

  return(out)
}

#' Spatial Polygons Simulation - Marginal Systematic
#'
#' @param n_2 \code{integer} number of polygons from pattern 2;
#' @param relation \code{character} that represents the relationship
#' between the two patterns. Valid inputs are
#' c("independence", "attraction", "repulsion");
#' @param r \code{numeric} representing the size of the polygons, if \code{r_2} is inputed
#' then \code{r} represents the size of polygons from type 1;
#' @param r_2 \code{numeric} representing the size of the polygons from type 2;
#' @param r_att \code{numeric} only used if relation equal to "attraction".
#' Values between 0 and infinity. Low values indicate high attraction;
#' @param max_hc \code{numeric} only used if relation equal to "repulsion".
#' Values between 0 and infinity High values indicate high repulsion;
#' @param bbox \code{matrix} - represents the boundary box;
#' @param points_chull \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 1 if \code{points_chull_2} is set;
#' @param points_chull_2 \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 2;
#' @param nx \code{integer} number of points in x axis;
#' @param ny \code{integer} number of points in y axis;
#' @param dx \code{numeric} space between points in x axis (only used if nx is NULL);
#' @param dy \code{numeric} space between points in y axis (only used if ny is NULL);
#'
#' @importFrom stats runif
#' @importFrom stats ecdf
#' @import sp
#' @import spatstat
#' @return a \code{list} containing two process with the inputed relation.
#' @export
sim_data_sys <- function(n_2 = 10, relation = "independence",
                         r = .25, r_2 = r,
                         r_att = NULL, max_hc = NULL,
                         bbox = matrix(rep(c(0, 10), 2), ncol = 2, byrow = T),
                         points_chull = 7,
                         points_chull_2 = points_chull,
                         nx = NULL, ny = NULL, dx = NULL, dy = NULL) {

  bbox_vec <- as.vector(c(bbox[1,], bbox[2,]))

  if(!relation %in% c("independence", "repulsion", "attraction")) {
    stop("type must be: independence, repulsion, or attraction.")
  }

  if(relation == "attraction" & is.null(r_att)) {
    stop("If type equal to attraction, then r_att must be informed.")
  }

  if(relation == "repulsion" & is.null(max_hc)) {
    stop("If type equal to attraction, then max_hc must be informed.")
  }

  if(relation %in% c("independence", "attraction")) {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq1 <- spatstat::rsyst(nx = nx, ny = ny,
                           dx = dx, dy = dx,
                           win = bbox_vec)

    # rm(ab)

    aux <- vector(mode = 'list', length = length(Sq1$x))

    for(i in seq_along(Sq1$x)) {
      pts_chull <- unif_circle(n = points_chull, cx = Sq1$x[i],
                               cy = Sq1$y[i], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    rm(aux)
  }

  if(relation == "independence") {
    # ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

    Sq2 <- list(x = runif(n = n_2, min = bbox[1, 1], max = bbox[1, 2]),
                y = runif(n = n_2, min = bbox[2, 1], max = bbox[2, 2]))

    # rm(ab)

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

  }

  if(relation == "attraction") {
    Sq2 <- list(x = vector(mode = 'numeric', length = n_2),
                y = vector(mode = 'numeric', length = n_2))

    aux <- vector(mode = 'list', length = n_2)

    for(i in seq_len(n_2)) {
      k <- sample(seq_len(length(sq1)), 1)

      # coords <- spatstat::runifdisc(n = 1, radius = r_att,
      #                               centre = sq1@polygons[[k]]@labpt)

      coords <- unif_circle(n = 1, cx = sq1@polygons[[k]]@labpt[1],
                            cy = sq1@polygons[[k]]@labpt[2], r = r_att)

      x <- coords[, 1]
      y <- coords[, 2]

      if(!spatstat::inside.owin(x, y, bbox_vec)) {
        if(x > max(bbox[1,]) | x < min(bbox[1,])) x <- runif(1, bbox[1, 1], bbox[1, 2])
        if(y > max(bbox[2,]) | y < min(bbox[2,])) y <- runif(1, bbox[2, 1], bbox[2, 2])
      }

      Sq2$x[i] <- x
      Sq2$y[i] <- y

      pts_chull <- unif_circle(n = points_chull_2, cx = Sq2$x[i],
                               cy = Sq2$y[i], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- SpatialPolygons(aux)

    rm(Sq2, aux, coords)
  }

  if(relation == "repulsion") {

    if(n_1 == n_2) {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  ptypes = c(.5, .5),
                  w = bbox_vec)
    } else {
      mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                  types = c("a", "b"),
                  w = bbox_vec)
    }

    Hard <- spatstat::rmh(model = mod, start=list(n.start = c(n_1, n_2)),
                          control = list(nrep = 1e4, nverb = 0, p = 1,
                                         fixall = T), verbose = F)

    # Extracting informations

    Sqs_hard <- data.frame(x = Hard$x, y = Hard$y,
                           type = Hard$marks)

    sq1_hard <- Sqs_hard[Sqs_hard$type == "a", ]
    sq2_hard <- Sqs_hard[Sqs_hard$type == "b", ]

    # Creating spatial objects - hardocre

    aux <- vector(mode = 'list', length = n_1)

    for(i in 1:nrow(sq1_hard)) {
      pts_chull <- unif_circle(n = points_chull, cx = sq1_hard[i, 'x'],
                               cy = sq1_hard[i, 'y'], r = r)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq1 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))

    aux <- vector(mode = 'list', length = n_2)

    for(i in 1:nrow(sq2_hard)) {
      pts_chull <- unif_circle(n = points_chull_2, cx = sq2_hard[i, 'x'],
                               cy = sq2_hard[i, 'y'], r = r_2)
      ids_chull <- grDevices::chull(x = pts_chull[, 1], y = pts_chull[, 2])
      ids_chull <- c(ids_chull, ids_chull[1])
      aux[[i]] <- sp::Polygons(list(sp::Polygon(pts_chull[ids_chull, ])),
                               ID = as.character(i))
    }

    sq2 <- sp::disaggregate(rgeos::gUnaryUnion(sp::SpatialPolygons(aux)))
  }

  sq1 <- rgeos::gIntersection(sq1, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq1))
  sq2 <- rgeos::gIntersection(sq2, tpsa:::limits_to_sp(bbox), byid = T,
                              id = names(sq2))

  attr(sq1, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  attr(sq2, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                              dimnames = list(c("x", "y"),
                                              c("min", "max")))

  out <- list(sq1, sq2)

  rm(list = ls()[ls() != "out"])

  return(out)
}
