#' Auxiliar Function to Calculate the power associated Toroidal Shift and different test statistics
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param ts \code{character} indicating the test statistic.
#' Can be c("psam", "pk_dist12", "pk_area12")
#' @param correction \code{character} indicating the edge correction.
#' Can be c("none", "torus", "guard", "adjust")
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{data.frame} with power informations
#' @export
#'
ts_power <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                     alpha = 0.01, ts = 'psam', correction = 'none') {

  unique_bbox <- obj_sp1@bbox

  if(alternative == 'independence') alternative <- 'two_sided'

  h_test <- tpsa::psat_mc_top(obj_sp1 = obj_sp1, obj_sp2 = obj_sp2, n_sim = nsim,
                               unique_bbox = unique_bbox, ts = ts,
                               correction = correction, alpha = alpha,
                               alternative = alternative)

  if(ts == 'psam') {
    output <- h_test$rejects
  } else {
    if(alternative == 'attraction') {
      output <- any(h_test$sample_ts$pk12 > h_test$mc_ts$k12_up, na.rm = T)
    }
    if(alternative == 'repulsion') {
      output <- any(h_test$sample_ts$pk12 < h_test$mc_ts$k12_inf, na.rm = T)
    }
    if(alternative == 'two_sided') {
      output <- any(h_test$sample_ts$pk12 < h_test$mc_ts$k12_inf | h_test$sample_ts$pk12 > h_test$mc_ts$k12_up, na.rm = T)
    }
  }

  rm(list = ls()[ls() != 'output'])

  return(output)
}

#' Auxiliar function to calculate the power of the test given some ts and ec
#'
#' @param nsim \code{integer}
#' @param iter \code{integer}
#' @param max_hc \code{numeric}
#' @param r_att \code{numeric}
#' @param n_1 \code{integer}
#' @param n_2 \code{integer}
#' @param r \code{numeric}
#' @param ts \code{character} indicating the test statistic.
#' Can be c("psam", "pk_dist12", "pk_area12")
#' @param correction \code{character} indicating the edge correction.
#' Can be c("none", "torus", "guard", "adjust")
#' @param alpha \code{numeric}
#' @param bbox \code{matrix}
#' @param alternative \code{character}
#' @param try_catch \code{boolean}
#'
#' @return \code{data.frame}
#' @export
#'
power_aux_ts <- function(nsim = 100, iter = 100, max_hc = NULL, r_att = NULL,
                         n_1 = 5, n_2 = 5, r = .25, alpha = 0.01,
                         bbox = matrix(c(0, 1, 0, 1),
                                       byrow = T, ncol = 2),
                         alternative = "attraction", ts, correction, try_catch = F) {

  aux <- vector(mode = 'numeric', length = iter)

  if(alternative == "attraction") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     r_att = r_att,
                                     bbox = bbox)

      if(try_catch) {
        aux[i] <- tryCatch({ts_power(obj_sp1 = sp_data[[1]],
                                     obj_sp2 = sp_data[[2]],
                                     nsim = nsim,
                                     alternative = alternative,
                                     ts = ts, correction = correction,
                                     alpha = alpha)},
                           error = function(cond) {
                             return(NA)
                           })
      } else {
        aux[i] <- ts_power(obj_sp1 = sp_data[[1]],
                           obj_sp2 = sp_data[[2]],
                           nsim = nsim,
                           alternative = alternative,
                           ts = ts, correction = correction,
                           alpha = alpha)
      }

    }

    output <- cbind(ts = ts, correction = correction, r_att = r_att,
                    power = mean(aux, na.rm = T),
                    niter = length(stats::na.exclude(aux)))
  }

  if(alternative == "repulsion") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     max_hc = max_hc,
                                     bbox = bbox)

      if(try_catch) {
        aux[i] <- tryCatch({ts_power(obj_sp1 = sp_data[[1]],
                                     obj_sp2 = sp_data[[2]],
                                     nsim = nsim,
                                     alternative = alternative,
                                     ts = ts, correction = correction,
                                     alpha = alpha)},
                           error = function(cond) {
                             return(NA)
                           })
      } else {
        aux[i] <- ts_power(obj_sp1 = sp_data[[1]],
                           obj_sp2 = sp_data[[2]],
                           nsim = nsim,
                           alternative = alternative,
                           ts = ts, correction = correction,
                           alpha = alpha)
      }
    }

    output <- cbind(ts = ts, correction = correction, hc = max_hc,
                    power = mean(aux, na.rm = T),
                    niter = length(stats::na.exclude(aux)))
  }

  if(alternative == "independence") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     bbox = bbox)

      if(try_catch) {
        aux[i] <- tryCatch({ts_power(obj_sp1 = sp_data[[1]],
                                     obj_sp2 = sp_data[[2]],
                                     nsim = nsim,
                                     alternative = alternative,
                                     ts = ts, correction = correction,
                                     alpha = alpha)},
                           error = function(cond) {
                             return(NA)
                           })
      } else {
        aux[i] <- ts_power(obj_sp1 = sp_data[[1]],
                           obj_sp2 = sp_data[[2]],
                           nsim = nsim,
                           alternative = alternative,
                           ts = ts, correction = correction,
                           alpha = alpha)
      }

    }

    output <- cbind(ts = ts, correction = correction,
                    power = mean(aux, na.rm = T),
                    niter = length(stats::na.exclude(aux)))
  }

  rm(list = ls()[ls() != 'output'])
  return(output)

}
