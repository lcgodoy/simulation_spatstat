.onAttach <- function(libname, pkgname) {
  packageStartupMessage("WARNING: The purpose of this package is support tpsa.")
}
