#' Spatial Polygons Simulation - alternative approach
#'
#' @param n_1 \code{integer} number of polygons from pattern 1;
#' @param n_2 \code{integer} number of polygons from pattern 2;
#' @param relation \code{character} that represents the relationship
#' between the two patterns. Valid inputs are
#' c("independence", "attraction", "repulsion");
#' @param r \code{numeric} representing the size of the polygons, if \code{r_2} is inputed
#' then \code{r} represents the size of polygons from type 1;
#' @param r_2 \code{numeric} representing the size of the polygons from type 2;
#' @param r_att \code{numeric} only used if relation equal to "attraction".
#' Values between 0 and infinity. Low values indicate high attraction;
#' @param max_hc \code{numeric} only used if relation equal to "repulsion".
#' Values between 0 and infinity High values indicate high repulsion;
#' @param bbox \code{matrix} - represents the boundary box;
#' @param points_chull \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 1 if \code{points_chull_2} is set;
#' @param points_chull_2 \code{integer} bigger values turns polygons in
#' circles, shape of polygons from type 2;
#' @param beta_1 \code{numeric} only used if relation equal to "repulsion".
#' Represents the intensity of the pattern 1;
#' @param beta_2 \code{numeric} \code{numeric} only used if relation equal to "repulsion".
#' Represents the intensity of the pattern 2.
#'
#' @importFrom stats runif
#' @importFrom stats ecdf
#' @return a \code{list} containing two process with the inputed relation.
#' @export
#'
sim_data2 <- function(n_1 = 10, n_2 = 10, relation = "independence",
                      r = .25, r_2 = r,
                      r_att = NULL, max_hc = NULL,
                      bbox = matrix(rep(c(0, 10), 2), ncol = 2, byrow = T),
                      points_chull = 7,
                      points_chull_2 = points_chull,
                      beta_1 = 1, beta_2 = 1) {

    bbox_vec <- as.vector(c(bbox[1,], bbox[2,]))

    if(!relation %in% c("independence", "repulsion", "attraction")) {
        stop("type must be: independence, repulsion, or attraction.")
    }

    if(relation == "attraction" & is.null(r_att)) {
        stop("If type equal to attraction, then r_att must be informed.")
    }

    if(relation == "repulsion" & is.null(max_hc)) {
        stop("If type equal to attraction, then max_hc must be informed.")
    }

    if(relation == "attraction") {
        ab <- spatstat::rmpoint(n = n_1, types = 1, win = bbox_vec)

        Sq1 <- list(x = ab$x, y = ab$y)

        rm(ab)

        aux <- list()

        for(i in seq_len(n_1)) {
            aux_ <- spatstat.geom::convexhull(
                                       spatstat::runifdisc.random(
                                                     n = points_chull,
                                                     centre = c(Sq1$x[i],  Sq1$y[i]),
                                                     r = r
                                                 )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq1 <- sp::SpatialPolygons(aux)

        rm(aux)
        gc(reset = T)

        Sq2 <- list(x = NULL, y = NULL)

        aux <- list()

        for(i in seq_len(n_2)) {
            k <- sample(seq_len(n_1), 1)

            coords <- spatstat.random::runifdisc(
                                           n = 1, radius = r_att,
                                           centre = sq1@polygons[[k]]@labpt
                                       )

            x <- coords$x
            y <- coords$y

            if(!spatstat.geom::inside.owin(x, y, bbox_vec)) {
                if(x > max(bbox[1,]) | x < min(bbox[1,])) x <- runif(1, bbox[1, 1], bbox[1, 2])
                if(y > max(bbox[2,]) | y < min(bbox[2,])) y <- runif(1, bbox[2, 1], bbox[2, 2])
            }

            Sq2$x[i] <- x
            Sq2$y[i] <- y

            aux_ <- spatstat.geom::convexhull(
                                       spatstat::runifdisc(
                                                     n = points_chull_2,
                                                     centre = c(Sq2$x[i], Sq2$y[i]),
                                                     r = r_2
                                                 )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq2 <- sp::SpatialPolygons(aux)

        rm(Sq2, aux, aux_, coords)
    }

    if(relation == "independence") {

        mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = 0),
                    types = c("a", "b"),
                    ptypes = c(n_1/(n_1 + n_2), n_2/(n_1 + n_2)),
                    w = bbox_vec)

        Hard <- spatstat.random::rmh(model = mod, start=list(n.start = c(n_1, n_2)),
                                     control = list(nrep = 1e4, nverb = 0, p = 1,
                                                    fixall = T), verbose = F)

                                        # Extracting informations

        Sqs_hard <- data.frame(x = Hard$x, y = Hard$y,
                               type = Hard$marks)

        sq1_hard <- Sqs_hard[Sqs_hard$type == "a", ]
        sq2_hard <- Sqs_hard[Sqs_hard$type == "b", ]

                                        # Creating spatial objects - hardocre

        aux <- list()

        for(i in 1:nrow(sq1_hard)) {
            aux_ <- spatstat.geom::convexhull(
                                       spatstat.geom::runifdisc(
                                                          n = points_chull,
                                                          centre = c(sq1_hard[i, "x"],
                                                                     sq1_hard[i, "y"]),
                                                          r = r
                                                      )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq1 <- sp::SpatialPolygons(aux)

        aux <- list()

        for(i in 1:nrow(sq2_hard)) {
            aux_ <- spatstat.geom::convexhull(
                                       spatstat.geom::runifdisc(
                                                          n = points_chull_2,
                                                          centre = c(sq2_hard[i, "x"],
                                                                     sq2_hard[i, "y"]),
                                                          r = r_2
                                                      )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq2 <- sp::SpatialPolygons(aux)
    }

    if(relation == "repulsion") {

        if(n_1 == n_2) {
            mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                        types = c("a", "b"),
                        ptypes = c(.5, .5),
                        w = bbox_vec)
        } else {
            mod <- list(cif = "hardcore",par = list(beta = c(beta_1, beta_2), hc = max_hc),
                        types = c("a", "b"),
                        w = bbox_vec)
        }

        Hard <- spatstat.random::rmh(model = mod, start=list(n.start = c(n_1, n_2)),
                                     control = list(nrep = 1e4, nverb = 0, p = 1,
                                                    fixall = T), verbose = F)
        
                                        # Extracting informations

        Sqs_hard <- data.frame(x = Hard$x, y = Hard$y,
                               type = Hard$marks)

        sq1_hard <- Sqs_hard[Sqs_hard$type == "a", ]
        sq2_hard <- Sqs_hard[Sqs_hard$type == "b", ]

                                        # Creating spatial objects - hardocre

        aux <- list()

        for(i in 1:nrow(sq1_hard)) {
            aux_ <- spatstat.geom::convexhull(
                                       spatstat.geom::runifdisc(
                                                          n = points_chull,
                                                          centre = c(sq1_hard[i, "x"],
                                                                     sq1_hard[i, "y"]),
                                                          r = r
                                                      )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq1 <- sp::SpatialPolygons(aux)

        aux <- list()

        for(i in 1:nrow(sq2_hard)) {
            aux_ <- spatstat.geom::convexhull(
                                       spatstat.geom::runifdisc(
                                                          n = points_chull_2,
                                                          centre = c(sq2_hard[i, "x"],  sq2_hard[i, "y"]),
                                                          r = r_2
                                                      )
                                   )

            aux_ <- cbind(x = aux_$bdry[[1]]$x, y = aux_$bdry[[1]]$y)
            aux_ <- rbind(aux_, aux_[1, ])
            aux[[i]] <- sp::Polygons(list(sp::Polygon(aux_)), ID = as.character(i))
        }

        sq2 <- sp::SpatialPolygons(aux)
    }

    sq1 <- rgeos::gIntersection(sq1, tpsa:::limits_to_sp(bbox), byid = T,
                                id = names(sq1))
    sq2 <- rgeos::gIntersection(sq2, tpsa:::limits_to_sp(bbox), byid = T,
                                id = names(sq2))

    attr(sq1, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                                dimnames = list(c("x", "y"),
                                                c("min", "max")))

    attr(sq2, "bbox") <- matrix(bbox_vec, ncol = 2, byrow = T,
                                dimnames = list(c("x", "y"),
                                                c("min", "max")))

    out <- list(sq1, sq2)

    rm(list = ls()[ls() != "out"])

    gc(reset = T)

    return(out)
}
