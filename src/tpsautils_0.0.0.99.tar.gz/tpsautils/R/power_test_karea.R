#' Toroidal Shift with $k_[1,2]$ area-based test statistic
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{data.frame} with power informations
#' @export
#'
mc_power_karea <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                           alpha = 0.01) {

  unique_bbox <- obj_sp1@bbox
  output <- vector(mode = "logical", length = 1)
  aux_k1 <- vector(mode = "numeric", length = nsim)
  aux_k2 <- vector(mode = "numeric", length = nsim)
  aux_k3 <- vector(mode = "numeric", length = nsim)

  rmax <- .3*max(unique_bbox[1,2] - unique_bbox[1,1],
                 unique_bbox[1,2] - unique_bbox[1,1])
  rmin <- .05*max(unique_bbox[1,2] - unique_bbox[1,1],
                  unique_bbox[1,2] - unique_bbox[1,1])

  karea_aux <- tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                               r_min = rmin, r_max = rmax, by = (rmax - rmin)/2)

  sample_k1 <- karea_aux[1,2] %>% as.numeric
  sample_k2 <- karea_aux[2,2] %>% as.numeric
  sample_k3 <- karea_aux[3,2] %>% as.numeric

  obj1_shift <- tpsa:::poly_shift(obj_sp = obj_sp1, bbox_tot = unique_bbox)
  obj2_shift <- tpsa:::poly_shift(obj_sp = obj_sp2, bbox_tot = unique_bbox)

  for(i in seq_len(nsim/2)) {
    obj2_rf <- tpsa:::poly_rf2(obj_sp2, obj1_shift@bbox)
    obj1_aux <- obj1_shift
    obj1_aux <- rgeos::gIntersection(obj1_shift, tpsa:::limits_to_sp(obj2_rf@bbox), byid = T,
                                     id = suppressWarnings(names(obj1_aux)))

    karea_aux <- tpsa::pk_area12(obj1_aux, obj2_rf, r_min = rmin,
                                r_max = rmax, by = (rmax - rmin)/2,
                                bbox = obj2_rf@bbox)

    aux_k1[i] <- karea_aux[1,2] %>% as.numeric
    aux_k2[i] <- karea_aux[2,2] %>% as.numeric
    aux_k3[i] <- karea_aux[3,2] %>% as.numeric
  }

  for(i in (nsim/2+1):nsim) {
    obj1_rf <- tpsa:::poly_rf2(obj_sp1, obj2_shift@bbox)
    obj2_aux <- obj2_shift
    obj2_aux <- rgeos::gIntersection(obj2_shift, tpsa:::limits_to_sp(obj1_rf@bbox), byid = T,
                                     id = suppressWarnings(names(obj2_aux)))

    karea_aux <-  tpsa::pk_area12(obj2_aux, obj1_rf, r_min = rmin,
                                 r_max = rmax, by = (rmax - rmin)/2,
                                 bbox = obj1_rf@bbox)

    aux_k1[i] <- karea_aux[1,2] %>% as.numeric
    aux_k2[i] <- karea_aux[2,2] %>% as.numeric
    aux_k3[i] <- karea_aux[3,2] %>% as.numeric
  }

  sample_ts <- list(sample_k1, sample_k2, sample_k3)

  torus_ts <- list(aux_k1, aux_k2, aux_k3)

  p_s <- vector(mode = 'numeric', length = length(sample_ts))

  if(alternative == "attraction") {
    for(i in seq_along(sample_ts)) {
      p_s[i] <- mean(sample_ts[[i]] < torus_ts[[i]])
    }
  }

  if(alternative == "repulsion") {
    for(i in seq_along(sample_ts)[-1]) {
      p_s[i] <- mean(sample_ts[[i]] > torus_ts[[i]])
    }
  }

  names(p_s) <- c("k1", "k2", "k3")

  output <- any(p_s < alpha)

  names(output) <- c("k_area")

  return(output)
}

#' Auxiliar function to calculate the power of the test
#' with k area-based ts
#'
#' @param nsim \code{integer}
#' @param iter \code{integer}
#' @param max_hc \code{numeric}
#' @param r_att \code{numeric}
#' @param n_1 \code{integer}
#' @param n_2 \code{integer}
#' @param r \code{numeric}
#' @param alpha \code{numeric}
#' @param bbox \code{matrix}
#' @param alternative \code{character}
#'
#' @return \code{data.frame}
#' @export
#'
power_aux_karea <- function(nsim = 100, iter = 100, max_hc = NULL, r_att = NULL,
                      n_1 = 5, n_2 = 5, r = .25, alpha = 0.01,
                      bbox = matrix(c(0, 1, 0, 1),
                                    byrow = T, ncol = 2),
                      alternative = "attraction") {

  K <- vector(mode = "numeric", length = iter)


  if(alternative == "attraction") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     r_att = r_att,
                                     bbox = bbox)

      aux <- try(suppressWarnings(mc_power_karea(obj_sp1 = sp_data[[1]],
                                           obj_sp2 = sp_data[[2]],
                                           nsim = nsim,
                                           alternative = alternative,
                                           alpha = alpha)))

      while("try-error" %in% class(aux)) {
        sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                       relation = alternative,
                                       max_hc = max_hc,
                                       bbox = bbox)

        aux <- try(suppressWarnings(mc_power_karea(obj_sp1 = sp_data[[1]],
                                             obj_sp2 = sp_data[[2]],
                                             nsim = nsim,
                                             alternative = alternative,
                                             alpha = alpha)))
      }

      K[i] <- aux
    }
    output <- data.frame(r_att = r_att, K_area = mean(K))
  }

  if(alternative == "repulsion") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     max_hc = max_hc,
                                     bbox = bbox)

      aux <- try(suppressWarnings(mc_power_karea(obj_sp1 = sp_data[[1]],
                                           obj_sp2 = sp_data[[2]],
                                           nsim = nsim,
                                           alternative = alternative,
                                           alpha = alpha)))

      while("try-error" %in% class(aux)) {
        sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                       relation = alternative,
                                       max_hc = max_hc,
                                       bbox = bbox)

        aux <- try(suppressWarnings(mc_power_karea(obj_sp1 = sp_data[[1]],
                                             obj_sp2 = sp_data[[2]],
                                             nsim = nsim,
                                             alternative = alternative,
                                             alpha = alpha)))
      }

      K[i] <- aux
    }
    output <- data.frame(hc_distance = max_hc, K_area = mean(K))
  }

  return(output)

}
