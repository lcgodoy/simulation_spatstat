#' Calculate the maximum Hard Core distance of a process,
#' given a number of points \code{n} and a \code{bbox}
#'
#' @param n \code{integer} representing the number of polygons.
#' @param bbox \code{matrix} representing the boundary box.
#'
#' @return an \code{integer}.
#' @export
#'
max_hc <- function(n, bbox) {
  x <- bbox[1,2] - bbox[1,1]
  y <- bbox[2,2] - bbox[2,1]

  out <- x*y
  out <- out/(pi*n)
  out <- sqrt(out)

  rm(list = ls()[ls() != "out"])

  return(out)
}
