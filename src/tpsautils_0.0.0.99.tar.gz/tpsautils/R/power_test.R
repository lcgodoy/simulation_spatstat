#' Toroidal Shift with different test statistics
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{data.frame} with power informations
#' @export
#' @import tpsa
#' @import purrr
#' @import rgeos
#'
mc_power <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                     alpha = 0.01) {

  unique_bbox <- obj_sp1@bbox
  output <- vector(mode = "logical", length = 19)
  sample <- vector(mode = "list", length = 19)
  mc <- vector(mode = "list", length = 19)

  names(sample) <- names(mc) <-
    c('psam_none', 'psam_guard', 'psam_torus',
      'kdist1_none', 'kdist1_guard', 'kdist1_torus', 'kdist1_adjust',
      'kdist2_none', 'kdist2_guard', 'kdist2_torus', 'kdist2_adjust',
      'karea1_none', 'karea1_guard', 'karea1_torus', 'karea1_adjust',
      'karea2_none', 'karea2_guard', 'karea2_torus', 'karea2_adjust')

  rmax <- .2*max(unique_bbox[1,2] - unique_bbox[1,1],
                 unique_bbox[1,2] - unique_bbox[1,1])
  rmin <- .05*max(unique_bbox[1,2] - unique_bbox[1,1],
                  unique_bbox[1,2] - unique_bbox[1,1])

  for(k in seq_along(sample)) {
    mc[[k]] <- vector(mode = 'numeric', length = nsim)

    if(stringr::str_detect(names(sample)[k], 'psam')) {
      if(stringr::str_detect(names(sample)[k], 'none')) {
        sample[[k]] <- tryCatch({tpsa::psam(obj_sp1, obj_sp2, correction = 'none')},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'guard')) {
        sample[[k]] <- tryCatch({tpsa::psam(obj_sp1, obj_sp2, correction = 'guard', guard_perc = .1)},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'torus')) {
        sample[[k]] <- tryCatch(tpsa::psam(obj_sp1, obj_sp2, correction = 'torus'),
                                error = function(cond) {
                                  return(NA)
                                })
      }
    }

    if(stringr::str_detect(names(sample)[k], 'kdist1')) {
      if(stringr::str_detect(names(sample)[k], 'none')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'none')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'guard')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'guard',
                                                 guard_perc = .1)[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'torus')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'torus')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'adjust')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'adjust')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
    }

    if(stringr::str_detect(names(sample)[k], 'kdist2')) {
      if(stringr::str_detect(names(sample)[k], 'none')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'none')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'guard')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'guard',
                                                 guard_perc = .1)[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'torus')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'torus')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'adjust')) {
        sample[[k]] <- tryCatch({tpsa::pk_dist12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'adjust')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
    }

    if(stringr::str_detect(names(sample)[k], 'karea1')) {
      if(stringr::str_detect(names(sample)[k], 'none')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'none')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'guard')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'guard',
                                                 guard_perc = .1)[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'torus')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'torus')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'adjust')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmin, r_max = rmin, by = 0,
                                                 correction = 'adjust')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
    }

    if(stringr::str_detect(names(sample)[k], 'karea2')) {
      if(stringr::str_detect(names(sample)[k], 'none')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'none')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'guard')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'guard',
                                                 guard_perc = .1)[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'torus')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'torus')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
      if(stringr::str_detect(names(sample)[k], 'adjust')) {
        sample[[k]] <- tryCatch({tpsa::pk_area12(obj_sp1, obj_sp2, bbox = unique_bbox,
                                                 r_min = rmax, r_max = rmax, by = 0,
                                                 correction = 'adjust')[1,2]},
                                error = function(cond) {
                                  return(NA)
                                })
      }
    }
  }

  obj1_shift <- tpsa:::poly_shift(obj_sp = obj_sp1, bbox_tot = unique_bbox)
  obj2_shift <- tpsa:::poly_shift(obj_sp = obj_sp2, bbox_tot = unique_bbox)

  for(i in seq_len(nsim)) {
    if(i <= nsim/2) {
      obj2_rf <- tpsa:::poly_rf2(obj_sp2, obj1_shift@bbox)
      obj1_aux <- obj1_shift
      obj1_aux <- gIntersection(obj1_shift, tpsa:::limits_to_sp(obj2_rf@bbox), byid = T,
                                id = suppressWarnings(names(obj1_aux)))

      for(k in seq_along(mc)) {

        if(stringr::str_detect(names(mc)[k], 'psam')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::psam(obj1_aux, obj2_rf, correction = 'none')
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::psam(obj1_aux, obj2_rf, correction = 'guard', guard_perc = .1)},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::psam(obj1_aux, obj2_rf, correction = 'torus')},
                                   error = function(cond) {return(NA)})
          }
        }

        if(stringr::str_detect(names(mc)[k], 'kdist1')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                          r_min = rmin, r_max = rmin, by = 0,
                                          correction = 'none')[1, 2]
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
        }

        if(stringr::str_detect(names(mc)[k], 'kdist2')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                          r_min = rmax, r_max = rmax, by = 0,
                                          correction = 'none')[1, 2]
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
        }

        if(stringr::str_detect(names(mc)[k], 'karea1')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'none')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
        }

        if(stringr::str_detect(names(mc)[k], 'karea2')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'none')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_aux, obj2_rf, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {
                                     return(NA)
                                   })
          }
        }
      }

    } else {
      obj1_rf <- tpsa:::poly_rf2(obj_sp1, obj2_shift@bbox)
      obj2_aux <- obj2_shift
      obj2_aux <- gIntersection(obj2_shift, tpsa:::limits_to_sp(obj1_rf@bbox), byid = T,
                                id = suppressWarnings(names(obj2_aux)))
      for(k in seq_along(mc)) {

        if(stringr::str_detect(names(mc)[k], 'psam')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::psam(obj1_rf, obj2_aux, correction = 'none')
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::psam(obj1_rf, obj2_aux, correction = 'guard', guard_perc = .1)},
                                   error = function(cond) {return(NA)})

          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::psam(obj1_rf, obj2_aux, correction = 'torus', guard_perc = .1)},
                                   error = function(cond) {return(NA)})
          }
        }

        if(stringr::str_detect(names(mc)[k], 'kdist1')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                          r_min = rmin, r_max = rmin, by = 0,
                                          correction = 'none')[1, 2]
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
        }

        if(stringr::str_detect(names(mc)[k], 'kdist2')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                          r_min = rmax, r_max = rmax, by = 0,
                                          correction = 'none')[1, 2]
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_dist12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
        }

        if(stringr::str_detect(names(mc)[k], 'karea1')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'none')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmin, r_max = rmin, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
        }

        if(stringr::str_detect(names(mc)[k], 'karea2')) {
          if(stringr::str_detect(names(mc)[k], 'none')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'none')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'guard')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'guard',
                                                    guard_perc = .1)[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'torus')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'torus')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
          if(stringr::str_detect(names(mc)[k], 'adjust')) {
            mc[[k]][i] <- tryCatch({tpsa::pk_area12(obj1_rf, obj2_aux, bbox = unique_bbox,
                                                    r_min = rmax, r_max = rmax, by = 0,
                                                    correction = 'adjust')[1, 2]},
                                   error = function(cond) {return(NA)})
          }
        }
      }
    }
  }


  # T_torus <- torus_ts %>%
  #   purrr::map(
  #     function(x) {
  #       aux <- stats::ecdf(x)
  #       aux(x)
  #     }
  #   ) %>%
  #   purrr::map(log) %>%
  #   purrr::pmap_dbl(sum) * (-2)

  p_s <- vector(mode = 'numeric', length = 19)

  names(p_s) <- names(sample)

  if(alternative == "attraction") {
    for(i in seq_along(sample)) {
      if(stringr::str_detect(names(sample)[i], 'psam')) {
        p_s[i] <- mean(sample[[i]] > mc[[i]])
      } else {
        p_s[i] <- mean(sample[[i]] < mc[[i]], na.rm = T)
      }
      output[i] <- p_s[i] < alpha
    }
  }

  if(alternative == "repulsion") {
    for(i in seq_along(sample)) {
      if(stringr::str_detect(names(sample)[i], 'psam')) {
        p_s[i] <- mean(sample[[i]] < mc[[i]])
      } else {
        p_s[i] <- mean(sample[[i]] > mc[[i]], na.rm = T)
      }
      output[i] <- p_s[i] < alpha
    }
  }

  # aux_T <- (-2*sum(log(p_s)))

  names(output) <- names(sample)

  return(output)
}

#' Auxiliar function to calculate the power of the test
#'
#' @param nsim \code{integer}
#' @param iter \code{integer}
#' @param max_hc \code{numeric}
#' @param r_att \code{numeric}
#' @param n_1 \code{integer}
#' @param n_2 \code{integer}
#' @param r \code{numeric}
#' @param alpha \code{numeric}
#' @param bbox \code{matrix}
#' @param alternative \code{character}
#'
#' @return \code{data.frame}
#' @export
#'
power_aux <- function(nsim = 100, iter = 100, max_hc = NULL, r_att = NULL,
                      n_1 = 5, n_2 = 5, r = .25, alpha = 0.01,
                      bbox = matrix(c(0, 1, 0, 1),
                                    byrow = T, ncol = 2),
                      alternative = "attraction") {

  out_aux <- vector(mode = "list", length = 11)
  names(out_aux) <- c('psam_none', 'psam_guard', 'psam_torus',
                      'kdist_none', 'kdist_guard', 'kdist_torus', 'kdist_adjust',
                      'karea_none', 'karea_guard', 'karea_torus', 'karea_adjust')

  for(k in 11) {
    out_aux[[k]] <- vector(mode = 'logical', length = iter)
  }

  if(alternative == "attraction") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     r_att = r_att,
                                     bbox = bbox)

      aux <- tryCatch({mc_power(obj_sp1 = sp_data[[1]],
                                obj_sp2 = sp_data[[2]],
                                nsim = nsim,
                                alternative = alternative,
                                alpha = alpha)},
                      error = function(cond) {
                        return(NA)
                      })

      for(k in seq_along(out_aux)) out_aux[[k]][i] <- aux[k]

    }
    out_aux <- sapply(out_aux, mean, na.rm = T)
    output <- cbind(ts = names(out_aux), r_att = r_att, power = out_aux)
  }

  if(alternative == "repulsion") {
    for(i in seq_len(iter)) {
      sp_data <- tpsautils::sim_data(n_1 = n_1, n_2 = n_2, r = r,
                                     relation = alternative,
                                     max_hc = max_hc,
                                     bbox = bbox)

      aux <- tryCatch({mc_power(obj_sp1 = sp_data[[1]],
                                obj_sp2 = sp_data[[2]],
                                nsim = nsim,
                                alternative = alternative,
                                alpha = alpha)},
                      error = function(cond) {
                        return(NA)
                      })

      for(k in seq_along(out_aux)) {
        # out_aux[[k]][i] <- aux[k]
        aux2 <- aux[(stringr::str_remove(names(aux), '[1-9]')) %in% names(out_aux)[k]]
        out_aux[[k]][i] <- any(aux2)
      }

    }
    out_aux <- sapply(out_aux, mean, na.rm = T)
    output <- cbind(ts = names(out_aux), hc = max_hc, power = out_aux)
  }

  return(output)

}

#' @useDynLib tpsautils
#' @importFrom Rcpp sourceCpp
#' @importFrom Rcpp evalCpp
NULL
