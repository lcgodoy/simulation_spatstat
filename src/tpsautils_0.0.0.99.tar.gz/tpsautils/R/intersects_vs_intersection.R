#' Two different toroidal shifts approach
#'
#' @param obj_sp1 a \code{SpatialPolygon}
#' @param obj_sp2 a \code{SpatialPolygon}
#' @param nsim \code{integer} giving the number of simulations for the``
#' Monte Carlo test.
#' @param alternative \code{character} indicating the alternative hypothesis.
#' Can be c("attraction", "repulsion").
#' @param alpha \code{numeric} between 0 and 1, representing the
#' type I error.
#'
#' @return \code{data.frame} with power informations
#' @export
#'
mc_intersects <- function(obj_sp1, obj_sp2, nsim, alternative = "attraction",
                          alpha = 0.01) {

  unique_bbox <- obj_sp1@bbox
  output <- vector(mode = "logical", length = 3)
  aux_psam <- matrix(nrow = nsim, ncol = 2) %>%
    `colnames<-`(c('intersection', 'intersects'))

  sample_psam <- tpsa::psam(obj_sp1, obj_sp2)

  obj1_shift <- tpsa:::poly_shift(obj_sp = obj_sp1, bbox_tot = unique_bbox)
  obj2_shift <- tpsa:::poly_shift(obj_sp = obj_sp2, bbox_tot = unique_bbox)

  ind_inter <- logical()

  for(i in seq_len(nsim)) {
    if(i <= nsim/2) {
      obj2_rf <- tpsa:::poly_rf2(obj_sp2, obj1_shift@bbox)
      obj1_aux1 <- obj1_shift
      obj1_aux2 <- obj1_shift
      obj1_aux1 <- gIntersection(obj1_shift, tpsa:::limits_to_sp(obj2_rf@bbox), byid = T,
                                 id = suppressWarnings(names(obj1_aux1)))
      obj1_aux2 <- obj1_aux2[rgeos::gIntersects(obj1_shift, tpsa:::limits_to_sp(obj2_rf@bbox), byid = T)]
      attr(obj1_aux2, 'bbox') <- obj2_rf@bbox
      attr(obj1_aux1, 'bbox') <- obj2_rf@bbox

      aux_psam[i, 1] <- tpsa::psam(obj1_aux1, obj2_rf)
      aux_psam[i, 2] <- tpsa::psam(obj1_aux2, obj2_rf)

    } else {
      obj1_rf <- tpsa:::poly_rf2(obj_sp1, obj2_shift@bbox)
      obj2_aux1 <- obj2_shift
      obj2_aux2 <- obj2_shift

      obj2_aux1 <- gIntersection(obj2_shift, tpsa:::limits_to_sp(obj1_rf@bbox), byid = T,
                                 id = suppressWarnings(names(obj2_aux1)))

      obj2_aux2 <- obj2_aux2[rgeos::gIntersects(obj2_shift, tpsa:::limits_to_sp(obj1_rf@bbox), byid = T)]
      aux_psam[i, 1] <- tpsa::psam(obj2_aux1, obj1_rf)
      aux_psam[i, 2] <- tpsa::psam(obj2_aux2, obj1_rf)
    }
  }


  p_s <- vector(mode = 'numeric', length = 2)

  if(alternative == "attraction") {
    p_s[1] <- mean(sample_psam > aux_psam[,1])
    p_s[2] <- mean(sample_psam > aux_psam[,2])
  }

  if(alternative == "repulsion") {
    p_s[1] <- mean(sample_psam < aux_psam[,1])
    p_s[2] <- mean(sample_psam < aux_psam[,2])
  }

  names(p_s) <- c("intersection", "intersects")

  output[1] <- p_s
  output[2] <- aux_psam[, 2]
  output[3] <- aux_psam[, 3]

  names(output) <- c("p_values", "ts_intersection", "ts_intersects")

  return(output)
}
