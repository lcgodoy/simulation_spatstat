#include <Rcpp.h>
using namespace Rcpp;

//' Generate data uniformly on circle
//'
//' @param n a \code{integer}
//' @param cx a \code{double}
//' @param cy a \code{double}
//' @param r a \code{double}
//'
//' @export
//'
// [[Rcpp::export]]
NumericMatrix unif_circle(int& n, double& cx, double& cy, double& r) {
  NumericMatrix output(n, 2);
  double x;
  double y;
  for(int i = 0; i < n; i++) {
    x = R::runif(-r, r);
    y = R::runif(-r, r);
    while(std::pow(x, 2) + std::pow(y, 2) > r) {
      x = R::runif(-r, r);
      y = R::runif(-r, r);
    }
    output(i, 0) = x + cx;
    output(i, 1) = y + cy;
  }

  return(output);
}


