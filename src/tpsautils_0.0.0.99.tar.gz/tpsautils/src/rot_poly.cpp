#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

S4 rot_poly_fixed(S4 sp_poly, float theta) {

  arma::mat bbox_obj = sp_poly.slot("bbox");

  arma::mat rot_mat = arma::zeros<arma::mat>(2, 2);
  rot_mat.at(0,0) = std::cos(theta);
  rot_mat.at(0,1) = std::sin(theta);
  rot_mat.at(1,0) = -std::sin(theta);
  rot_mat.at(1,1) = std::cos(theta);

  S4 output = clone(sp_poly);

  List polygons_aux = output.slot("polygons");

  int n_poly_1 = polygons_aux.size();

  for(int i = 0; i < n_poly_1; i++) {

    S4 out = polygons_aux[i];
    List polygons_aux2 = out.slot("Polygons");
    int n_poly_2 = polygons_aux2.size();

    for(int j = 0; j < n_poly_2; j++) {
      S4 out2 = polygons_aux2[j];
      arma::mat rot_polygons_aux = out2.slot("coords");
      arma::rowvec cent_polygons_aux = out2.slot("labpt");
      rot_polygons_aux.col(0) = rot_polygons_aux.col(0) - cent_polygons_aux.at(0);
      rot_polygons_aux.col(1) = rot_polygons_aux.col(1) - cent_polygons_aux.at(1);
      rot_polygons_aux = rot_polygons_aux*rot_mat;
      rot_polygons_aux.col(0) = rot_polygons_aux.col(0) + cent_polygons_aux.at(0);
      rot_polygons_aux.col(1) = rot_polygons_aux.col(1) + cent_polygons_aux.at(1);
      out2.slot("coords") = rot_polygons_aux;
      polygons_aux2[j] = out2;
    }
    out.slot("Polygons") = polygons_aux2;
    polygons_aux[i] = out;
  }

  output.slot("polygons") = polygons_aux;

  return(output);
}

S4 rot_poly(S4 sp_poly) {

  arma::mat bbox_obj = sp_poly.slot("bbox");

  arma::mat rot_mat = arma::zeros<arma::mat>(2, 2);

  float pi = 3.141592653589793238462643383280;
  float theta;

  S4 output = clone(sp_poly);

  List polygons_aux = output.slot("polygons");

  int n_poly_1 = polygons_aux.size();

  for(int i = 0; i < n_poly_1; i++) {

    S4 out = polygons_aux[i];
    List polygons_aux2 = out.slot("Polygons");
    int n_poly_2 = polygons_aux2.size();
    theta = Rcpp::runif(1, 0, 2*pi).at(0);

    for(int j = 0; j < n_poly_2; j++) {
      S4 out2 = polygons_aux2[j];
      arma::mat rot_polygons_aux = out2.slot("coords");
      arma::rowvec cent_polygons_aux = out2.slot("labpt");
      rot_mat.at(0,0) = std::cos(theta);
      rot_mat.at(0,1) = std::sin(theta);
      rot_mat.at(1,0) = -std::sin(theta);
      rot_mat.at(1,1) = std::cos(theta);
      rot_polygons_aux.col(0) = rot_polygons_aux.col(0) - cent_polygons_aux.at(0);
      rot_polygons_aux.col(1) = rot_polygons_aux.col(1) - cent_polygons_aux.at(1);
      rot_polygons_aux = rot_polygons_aux*rot_mat;
      rot_polygons_aux.col(0) = rot_polygons_aux.col(0) + cent_polygons_aux.at(0);
      rot_polygons_aux.col(1) = rot_polygons_aux.col(1) + cent_polygons_aux.at(1);
      out2.slot("coords") = rot_polygons_aux;
      polygons_aux2[j] = out2;
    }
    out.slot("Polygons") = polygons_aux2;
    polygons_aux[i] = out;
  }

  output.slot("polygons") = polygons_aux;

  return(output);
}

S4 random_recenter(S4 sp_poly) {

  arma::mat bbox_obj = sp_poly.slot("bbox");

  float x_min = bbox_obj.at(0, 0);
  float x_max = bbox_obj.at(0, 1);
  float y_min = bbox_obj.at(1, 0);
  float y_max = bbox_obj.at(1, 1);

  float x_new = 0;
  float y_new = 0;

  S4 output = clone(sp_poly);

  List polygons_aux = output.slot("polygons");

  int n_poly_1 = polygons_aux.size();

  for(int i = 0; i < n_poly_1; i++) {
    x_new = Rcpp::runif(1, x_min, x_max).at(0);
    y_new = Rcpp::runif(1, x_min, x_max).at(0);

    S4 out = polygons_aux[i];
    out.slot("labpt") = NumericVector::create(x_new, y_new);
    List polygons_aux2 = out.slot("Polygons");
    int n_poly_2 = polygons_aux2.size();

    for(int j = 0; j < n_poly_2; j++) {
      S4 out2 = polygons_aux2[j];
      arma::mat coord_aux = out2.slot("coords");
      arma::rowvec cent_polygons_aux = out2.slot("labpt");
      coord_aux.col(0) = coord_aux.col(0) - cent_polygons_aux.at(0);
      coord_aux.col(1) = coord_aux.col(1) - cent_polygons_aux.at(1);

      coord_aux.col(0) = coord_aux.col(0) + x_new;
      coord_aux.col(1) = coord_aux.col(1) + y_new;

      out2.slot("coords") = coord_aux;
      out2.slot("labpt") = NumericVector::create(x_new, y_new);
      polygons_aux2[j] = out2;
    }
    out.slot("Polygons") = polygons_aux2;
    polygons_aux[i] = out;
  }

  output.slot("polygons") = polygons_aux;

  return(output);
}

//' Simulate from null hypotheis using the approach from Wiegand et al
//'
//' @param sp_poly a \code{SpatialPolygon}
//'
// [[Rcpp::export]]
S4 null_wiegand(S4 sp_poly) {

  /* store bbox */
  arma::mat bbox = sp_poly.slot("bbox");

  /* random centering and rotation */
  S4 output = random_recenter(sp_poly);
  output = rot_poly(output);

  /* verifying if the process generated is valid */
  List polygons_aux = output.slot("polygons");

  int n_poly_1 = polygons_aux.size();

  bool flag_gen = true;
  arma::vec flag_x(n_poly_1);
  arma::vec flag_y(n_poly_1);

  for(int i = 0; i < n_poly_1; i++) {

    S4 out = polygons_aux[i];
    List polygons_aux2 = out.slot("Polygons");
    int n_poly_2 = polygons_aux2.size();
    arma::vec flag2_x(n_poly_2);
    arma::vec flag2_y(n_poly_2);

    for(int j = 0; j < n_poly_2; j++) {
      S4 out2 = polygons_aux2[j];
      arma::mat coord_aux = out2.slot("coords");
      flag2_x.at(j) = sum(coord_aux.col(0) < bbox.at(0, 0) + coord_aux.col(1) > bbox.at(0, 1));
      flag2_y.at(j) = sum(coord_aux.col(1) < bbox.at(1, 0) + coord_aux.col(1) > bbox.at(1, 1));
    }
    flag_x.at(i) = sum(flag2_x);
    flag_y.at(i) = sum(flag2_y);
  }

  if(sum(flag_x) == 0 && sum(flag_y) == 0) {
    flag_gen = false;
  }

  while(flag_gen) {
    /* random centering and rotation */
    S4 output = random_recenter(sp_poly);
    output = rot_poly(output);

    /* verifying if the process generated is valid */
    List polygons_aux = output.slot("polygons");

    int n_poly_1 = polygons_aux.size();

    bool flag_gen = true;
    arma::vec flag_x(n_poly_1);
    arma::vec flag_y(n_poly_1);

    for(int i = 0; i < n_poly_1; i++) {

      S4 out = polygons_aux[i];
      List polygons_aux2 = out.slot("Polygons");
      int n_poly_2 = polygons_aux2.size();
      arma::vec flag2_x(n_poly_2);
      arma::vec flag2_y(n_poly_2);

      for(int j = 0; j < n_poly_2; j++) {
        S4 out2 = polygons_aux2[j];
        arma::mat coord_aux = out2.slot("coords");
        flag2_x.at(j) = sum(coord_aux.col(0) < bbox.at(0, 0) + coord_aux.col(1) > bbox.at(0, 1));
        flag2_y.at(j) = sum(coord_aux.col(1) < bbox.at(1, 0) + coord_aux.col(1) > bbox.at(1, 1));
      }
      flag_x.at(i) = sum(flag2_x);
      flag_y.at(i) = sum(flag2_y);
    }

    if(sum(flag_x) == 0 && sum(flag_y) == 0) {
      flag_gen = false;
    }
  }

  return(output);

}
