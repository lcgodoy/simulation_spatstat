.onAttach <- function(libname, pkgname) {
  packageStartupMessage("An R package to test polygons spatial association \nWARNING: This package is under development")
}

# .onUnload <- function (libpath) {
#   library.dynam.unload('pat', libpath)
# }

