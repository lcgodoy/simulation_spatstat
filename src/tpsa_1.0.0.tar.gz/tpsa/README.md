[![Build Status](https://travis-ci.org/lcgodoy/tpsa.svg?branch=master)](https://travis-ci.org/lcgodoy/tpsa)

# Testing Polygons Spatial Association

An approach for testing ecological patches.

## Installation 

```r
# install.packages('devtools')
devtools::install_github('lcgodoy/tpsa')
```

## Note

The purpose of this package is to make available to end users a newly developed
method which was submitted for publication.
